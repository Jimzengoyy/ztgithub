//
//  TitleButton.h
//  CD1505Weibo
//
//  Created by 千锋 on 15/12/30.
//  Copyright © 2015年 jimproduct. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TitleButton : UIButton

@property(nonatomic,assign) CGFloat titleRatio;

@end

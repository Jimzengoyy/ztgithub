//
//  WBTabBar.h
//  CD1505Weibo
//
//  Created by 千锋 on 15/12/29.
//  Copyright (c) 2015年 jimproduct. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol WBTabBarDelegate <NSObject>

-(void)passIndex:(NSInteger)index;

@end

typedef void(^PassIndex)(NSInteger index);

typedef void (^PlubBtnPressedBlock)();

@interface WBTabBar : UIView

//用来传递title信息,image信息等
@property(nonatomic,strong) UITabBarItem * tabBarItem;

@property (nonatomic, weak) id <WBTabBarDelegate> delegate;

//传出标签选项的index
@property (nonatomic,copy) PassIndex passIndex;
//中间加号按钮点击的回调block
@property(nonatomic,copy) PlubBtnPressedBlock plBlock;

@end
